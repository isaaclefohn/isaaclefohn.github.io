# CHROMA Press Kit

This zip is intended for editorial coverage, App Store editorial
review, and TestFlight tester onboarding. It contains everything
you need to write about, review, or share CHROMA without emailing
back-and-forth for assets.

## Contents

- `icon-1024.png` — App Store icon (Concept E — Detonation Bead)
- `wordmark/wordmark-multihue-dark.png` — six-hue wordmark on dark
- `wordmark/wordmark-mono-dark.png` — monochrome white wordmark on dark
- `wordmark/wordmark-multihue-transparent.png` — for compositing
- `wordmark/wordmark.svg` — source SVG, scales to any size
- `screenshots/slot-1...6.png` — App Store screenshots at 1290x2796
- `og-card.png` — 1200x630 social-share card
- `fact-sheet.txt` — plain-text press info
- `description.txt` — short + long-form game descriptions
- `features.txt` — full feature list

## Brand colors

- Background: `#0F0E1A`
- Red `#FF3B5C` / Yellow `#FACC15` / Blue `#3B82F6` / Teal `#00D4AA` /
  Purple `#A855F7` / Orange `#FF6B2B`
- Green (`#22C55E`) is a gameplay color, NOT a brand color.

## Letter-to-hue mapping

`C`=Red · `H`=Yellow · `R`=Blue · `O`=Teal · `M`=Purple · `A`=Orange

## Typography

Primary: **Space Grotesk Bold** (SIL OFL, free for commercial use).
Backup: Outfit Bold (also SIL OFL).

## Contact

Isaac Lefohn — kiwilefohn@gmail.com — chroma.game

## License

All assets licensed for editorial coverage of CHROMA. Redistribution
outside coverage requires written permission.
